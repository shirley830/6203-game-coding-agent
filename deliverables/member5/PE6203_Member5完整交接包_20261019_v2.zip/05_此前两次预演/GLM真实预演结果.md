# GLM-5.3 真实游戏预演结果

日期：2026-10-19，Asia/Singapore。
Agent 源码版本：f8a514dbfaec509562ed8ab00af23552490efd0b（远程 main 的固定快照）。
模型：OpenRouter 上的 openrouter/z-ai/glm-5.3。
环境：macOS Apple Silicon、Python 3.12.14、严格 sandbox-exec、Playwright Headless Chromium。
这是开发预演，不是老师现场未知需求的正式考核结果。

## 结果

| 项目 | 网页收集游戏 | 非网页文字猜词游戏 |
|---|---|---|
| 测试需求 | dev_01_collect | dev_05_terminal |
| Agent 结果 | succeeded | succeeded |
| Agent 运行时间 | 59.67 秒 | 25.57 秒 |
| 模型调用次数 | 10 | 4 |
| 恢复次数 | 1 | 0 |
| 工具命令次数 | 2 | 1 |
| 必选检查 | 13 项通过 | 以所附 verification 报告为准 |
| 交付日志审计 | complete=true，无问题 | complete=true，无问题 |

网页游戏第一次验收发现运行错误（包括 canvas getContext 的空对象错误），功能和交互未通过。Agent 自动进入 REPAIR，修改后第二轮通过。没有人工修改运行中的游戏或 Agent 代码。非网页文字游戏使用进程模式验收，没有运行浏览器。

上面的耗时为 Agent 自身记录，不含安装环境、API 连通检查、人工观察和打包时间。本次每个需求仅运行一次，不能据此认定稳定成功率。模型费用字段未返回可用价格，因此未报告美元费用；以 OpenRouter 账户账单为准。

## 两种形式如何启动

生成游戏时，两者使用同一条 Agent 命令：

```bash
python -m agent game_design_prompt.md
```

Agent 根据本次需求生成游戏源代码和 README。现场不能提前手写游戏模板或让人补代码。

试玩本压缩包里的网页游戏，进入 web_collection/game 后运行：

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

浏览器打开 http://127.0.0.1:8000/，方向键移动、收集 10 个物品获胜，Restart 重置。

试玩非网页文字游戏，进入 terminal_hangman/game 后运行：

```bash
python3 main.py
```

按屏幕提示猜字母；游戏结束后可开始下一轮。具体操作见各自 game/README.md。

文字终端游戏不是 Pygame 桌面图形游戏。此轮未验证桌面窗口、图形输入或打包为 exe/app 的能力。

## 保留的证据

每次运行均附 game/、原始 traces/、需求与运行元数据。traces 包含 summary、完整事件、模型用量和验收报告；网页游戏包含截图。未附 agent.env 或其他含密钥的文件；导出前已检查所选文件不含当前 Key。原始运行目录仍保留在本机持久工作目录中。

这些游戏是该次预演由 Agent 生成的结果，不应作为下次现场生成的游戏模板。现场 API 平台或参数变化后，仍需先做连通及正文输出检查。
